import { FCParams } from '../common/index';

export type NetParams = {
  fc: FCParams
}
