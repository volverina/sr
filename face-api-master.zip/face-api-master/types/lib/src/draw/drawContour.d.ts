import { Point } from '../classes/index';
export declare function drawContour(ctx: CanvasRenderingContext2D, points: Point[], isClosed?: boolean): void;
