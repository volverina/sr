export declare function euclideanDistance(arr1: number[] | Float32Array, arr2: number[] | Float32Array): number;
