export declare function fetchJson<T>(uri: string): Promise<T>;
