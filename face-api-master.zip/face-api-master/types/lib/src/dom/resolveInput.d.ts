export declare function resolveInput(arg: string | any): any;
