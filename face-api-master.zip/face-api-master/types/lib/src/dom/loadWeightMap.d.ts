import * as tf from '../../dist/tfjs.esm';
export declare function loadWeightMap(uri: string | undefined, defaultModelName: string): Promise<tf.NamedTensorMap>;
