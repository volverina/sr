export declare function isBrowser(): boolean;
