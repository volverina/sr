import { Environment } from './types';
export declare function createNodejsEnv(): Environment;
