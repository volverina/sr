export declare function getModelUris(uri: string | undefined, defaultModelName: string): {
    modelBaseUri: string;
    manifestUri: string;
};
