import { ParamMapping } from './types';
export declare function extractWeightEntryFactory(weightMap: any, paramMappings: ParamMapping[]): (originalPath: string, paramRank: number, mappedPath?: string) => any;
