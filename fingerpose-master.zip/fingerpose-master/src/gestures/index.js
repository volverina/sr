import VictoryGesture from './Victory';
import ThumbsUpGesture from './ThumbsUp';

export {
  VictoryGesture,
  ThumbsUpGesture,
}
